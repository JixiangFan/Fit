//
//  HomeViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import SwiftDate
import VACalendar
import ESPullToRefresh
import DeallocationChecker

class HomeViewController: UIViewController {
    
    // MARK: - LifeCycle
    override func viewDidLoad() {
        
        super.viewDidLoad()
        setupBackgroundScrollView()
        setupCalendar()
        setupUserInfoView()
        setupPageView()
        setRefreshModule()
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        DeallocationChecker.shared.checkDeallocation(of: self)
    }
    
    let scrollBackground: UIScrollView! = UIScrollView()
    
    // MARK: - Calendar
    var isCalendarHidden: Bool = true
    let dateTitleBar: HomeDateSwitchBar! = HomeDateSwitchBar()
    let homeCalendar: HomeCalendar! = HomeCalendar()
    let userInfoView: UserInfoView! = UserInfoView()
    let pageView: HomePageViewController! = HomePageViewController()
}

// MARK: - Calendar Hidden Switch
extension HomeViewController {
    
    @objc func calendarSwitch() {
        
        isCalendarHidden = !isCalendarHidden
        dateTitleBar.switchStatus(isHidden: isCalendarHidden)
        homeCalendar.isHidden = isCalendarHidden
        view.setNeedsLayout()
    }
}

// MARK: - Init
extension HomeViewController {
    
    func setupBackgroundScrollView() {
        scrollBackground.backgroundColor = .groupTableViewBackground
        self.view.addSubview(scrollBackground)
    }
    
    func setupCalendar() {
        
        scrollBackground.addSubview(dateTitleBar)
        dateTitleBar.switchButton.addTarget(self, action: #selector(calendarSwitch), for: .touchUpInside)
        
        scrollBackground.addSubview(homeCalendar)
        homeCalendar.calendarTitle.delegate = self
        homeCalendar.calendarView.calendarDelegate = self
    }
    
    func setupUserInfoView() {
        scrollBackground.addSubview(userInfoView)
    }
    
    func setupPageView() {
        addChild(pageView)
        scrollBackground.addSubview(pageView.view)
    }
    
    // MARK: - Refresh
    
    func setRefreshModule() {
        scrollBackground.es.addPullToRefresh {
            [unowned self] in
            self.userInfoView.refresh()
            self.pageView.refresh()
            self.scrollBackground.es.stopPullToRefresh()
        }
    }
    
    func findUserTeamMates() {
        guard let teamInfo = UserDataCenter.shared.userInfo else { return }
    }
}






