//
//  HomeVC_UILayout.swift
//  FitAware
//
//  Created by Zfan on 2019/9/22.
//  Copyright © 2019 Zfan. All rights reserved.
//

import SnapKit
import VACalendar

extension HomeViewController {
    
    // MARK: - UI Layout Setup
    
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()
        
        scrollBackground.snp.makeConstraints { (make) in
            if #available(iOS 11.0, *) {
                make.top.bottom.left.right.equalTo(self.view.safeAreaLayoutGuide)
            } else {
                make.top.bottom.left.right.equalToSuperview()
            }
        }
        
        dateTitleBar.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.leading.trailing.equalTo(self.view.safeAreaLayoutGuide)
            } else {
                make.leading.trailing.equalTo(self.view)
            }
            make.height.equalTo(60.0)
        }
        
        homeCalendar.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(dateTitleBar)
            make.top.equalTo(dateTitleBar.snp.bottom)
            make.height.equalTo(280.0)
        }
        
        userInfoView.snp.remakeConstraints() { (make) in
            if isCalendarHidden {
                make.top.equalTo(dateTitleBar.snp.bottom)
            }
            else {
                make.top.equalTo(homeCalendar.snp.bottom)
            }
            if #available(iOS 11.0, *) {
                make.leading.trailing.equalTo(self.view.safeAreaLayoutGuide)
            } else {
                make.leading.trailing.equalTo(self.view)
            }
            make.height.equalTo(280.0)
        }
        
        pageView.view.snp.makeConstraints { (make) in
            make.top.equalTo(userInfoView.snp.bottom).offset(10.0)
            if #available(iOS 11.0, *) {
                make.leading.trailing.equalTo(self.view.safeAreaLayoutGuide)
            } else {
                make.leading.trailing.equalTo(self.view)
            }
            make.height.equalTo(400.0)
            make.bottom.equalToSuperview()
        }
    }
}
