//
//  UserInfoView.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import MKRingProgressView
import SnapKit

class UserInfoView: UIView {
    
    var teamMembers: [String] = []
    var teamSteps: UInt = 0

    // MARK: - Initialization
    
    init() {
        super.init(frame: .zero)
        
        self.backgroundColor = .white
        
        self.addSubview(progressView)
        self.addSubview(userTeamAvatar)
        self.addSubview(teamRankLabel)
        self.addSubview(teamNameLabel)
        self.addSubview(teamStepsLabel)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // MARK: - UI Setup
    
    let progressView: RingProgressView! = {
        $0.startColor = .red
        $0.endColor = .orange
        $0.ringWidth = 25
        $0.progress = 0.0
        return $0
    }(RingProgressView())
    
    let userTeamAvatar: UIImageView! = {
        $0.image = #imageLiteral(resourceName: "teamwork")
        return $0
    }(UIImageView())
    
    var teamRankLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 16.0)
        $0.textColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        $0.text = "No.1"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let teamNameLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 16.0)
        $0.textColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        $0.text = "You Have Not Joined Any Team"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let teamStepsLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 16.0)
        $0.textColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        $0.text = "0"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    // MARK: - Layout
    override func layoutSubviews() {
        
        super.layoutSubviews()
        progressView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10.0)
            make.centerX.equalToSuperview()
            make.width.height.equalTo(190.0)
        }
        userTeamAvatar.snp.makeConstraints { (make) in
            make.center.equalTo(progressView)
            make.height.width.equalTo(progressView).multipliedBy(0.7)
        }
        teamRankLabel.snp.makeConstraints { (make) in
            make.top.equalTo(progressView.snp.bottom).offset(10.0)
            make.centerX.leading.trailing.equalToSuperview()
            make.height.equalTo(20.0)
        }
        teamNameLabel.snp.makeConstraints { (make) in
            make.top.equalTo(teamRankLabel.snp.bottom).offset(2.0)
            make.centerX.leading.trailing.equalToSuperview()
            make.height.equalTo(20.0)
        }
        teamStepsLabel.snp.makeConstraints { (make) in
            make.top.equalTo(teamNameLabel.snp.bottom).offset(2.0)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(20.0)
        }
    }
}
