//
//  UserInfoView_Data.swift
//  FitAware
//
//  Created by Zfan on 2019/10/6.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import FirebaseUI
import SwiftDate
import Firebase

extension UserInfoView {

    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        refresh()
    }

    // MARK: - Data Setup
    
    func refresh() {
        
        requestData()
        requestIcon()
    }
    
    func requestData() {
        
        TeamDataCenter.shared.requestAllTeamData(completion: { (allTeamsInfo) in
            for (index, teamInfo) in allTeamsInfo.enumerated() {
                guard let teamName = teamInfo["TeamName"] as? String else { continue }
                if teamName == UserDataCenter.shared.userTeam {
                    self.teamNameLabel.text = teamName
                    self.teamRankLabel.text = "NO.\(String(index + 1))"
                    let teamStep = teamInfo["teamSteps"] as? String ?? "0"
                    let teamGoal = teamInfo["teamGoal"] as? String ?? "0"
                    self.teamStepsLabel.text = "\(teamStep)/\(teamGoal)"
                    let teamGoalCount = Double(teamGoal) ?? 0.0
                    let teamStepsCount = Double(teamStep) ?? 0.0
                    if (teamGoalCount == 0.0) {
                        self.progressView.progress = 1.0
                        return
                    } else {
                        self.progressView.progress = teamStepsCount / teamGoalCount
                    }
                }
            }
        }) {
            print("==== UserInfoView: TeamDataCenter Request Data Error")
        }
    }
        
    func requestIcon() {
        
        if let teamName = UserDataCenter.shared.userTeam {
            let referenceURL = "team_icon/\(teamName)/icon.jpg"
            let reference = Storage.storage().reference().child(referenceURL)
            userTeamAvatar.sd_setImage(with: reference, placeholderImage: #imageLiteral(resourceName: "teamwork.png"))
        }
    }
}
