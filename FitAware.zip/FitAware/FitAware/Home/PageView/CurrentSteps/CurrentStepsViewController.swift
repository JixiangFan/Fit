//
//  CurrentStepsViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import XLPagerTabStrip
import CoreMotion
import Charts

class CurrentStepsViewController: UIViewController, IndicatorInfoProvider {
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(image: #imageLiteral(resourceName: "Home_Current"))
    }

    override func viewDidLoad() {
        super.viewDidLoad()
            self.view.addSubview(chartView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        startRecordSteps()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRecordSteps()
    }
    
    // MARK: - UI Setup
    let chartView: BarChartView! = {
        let chartView = BarChartView()
        chartView.isUserInteractionEnabled = false
        let leftAxis = chartView.getAxis(.left)
        chartView.noDataText = "Waiting for data..."
//        let xAxis = chartView.xAxis
//        xAxis.labelPosition = .bottom
//        xAxis.labelFont = .systemFont(ofSize: 10)
//        xAxis.granularity = 1
//        xAxis.labelCount = 50
//        xAxis.valueFormatter =
        return chartView
    }()
    
    let monitor = CMPedometer()
    var timer: Timer?
    var stepsArr: [Int] = []
    
    func startRecordSteps() {
        self.monitor.queryPedometerData(from: Date().dateAt(.startOfDay), to: Date()) { (data, error) in
            print(data?.numberOfSteps.intValue ?? "No Current Steps")
            DispatchQueue.main.async {
                self.setDataCount(15, value: data?.numberOfSteps as! Int)
            }
        }
        timer = Timer.scheduledTimer(withTimeInterval: 8.0, repeats: true) { [weak self] (timer) in
            self?.monitor.queryPedometerData(from: Date().dateAt(.startOfDay), to: Date()) { (data, error) in
                print(data?.numberOfSteps.intValue ?? "No Current Steps")
                DispatchQueue.main.async {
                    self?.setDataCount(15, value: data?.numberOfSteps as! Int)
                }
            }
        }
    }
    
    func stopRecordSteps() {
        timer?.invalidate()
        timer = nil
    }
    
    var currentDatas: [BarChartDataEntry]? = []
    func setDataCount(_ count: Int, value: Int) {
        
        stepsArr.append(value)
        if (stepsArr.count > count) {
            stepsArr.removeFirst()
        }
        
        let start = 0
        let yVals = (start ..< count).map { (i) -> BarChartDataEntry in
            if i < stepsArr.count {
                let val = stepsArr[i]
                return BarChartDataEntry(x: Double(i), y: Double(val))
            } else {
                return BarChartDataEntry(x: Double(i), y: Double(0))
            }
        }
        
        var set1: BarChartDataSet! = nil
        if let set = chartView.data?.dataSets.first as? BarChartDataSet {
            set1 = set
            set1.replaceEntries(yVals)
            chartView.data?.notifyDataChanged()
            chartView.notifyDataSetChanged()
        }
        else {
            set1 = BarChartDataSet(entries: yVals, label: "Steps")
            set1.colors = ChartColorTemplates.material()
            set1.drawValuesEnabled = false

            let data = BarChartData(dataSet: set1)
            data.setValueFont(UIFont(name: "HelveticaNeue-Light", size: 10)!)
            data.barWidth = 0.9
            chartView.data = data
        }
    }
}

extension CurrentStepsViewController {
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        chartView.snp.makeConstraints { (make) in
            make.top.bottom.trailing.leading.equalToSuperview()
        }
    }
}
