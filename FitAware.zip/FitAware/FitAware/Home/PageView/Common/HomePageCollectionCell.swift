//
//  HomePageCollectionCell.swift
//  FitAware
//
//  Created by Zfan on 2019/9/29.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import MKRingProgressView
import SnapKit

class HomePageCollectionCell: UICollectionViewCell {
    
    @IBOutlet weak var progressRing: RingProgressView!
    @IBOutlet weak var playerIcon: UIImageView!
    @IBOutlet weak var rankLabel: UILabel!
    @IBOutlet weak var playerNameLabel: UILabel!
    @IBOutlet weak var totalStepsLabel: UILabel!
}
