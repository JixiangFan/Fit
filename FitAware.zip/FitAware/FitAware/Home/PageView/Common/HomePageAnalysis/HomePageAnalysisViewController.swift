//
//  HomePageAnalysisViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/26.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import MKRingProgressView
import Charts

class HomePageAnalysisViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(progressView)
        view.addSubview(percentLabel)
        view.addSubview(rankLabel)
        view.addSubview(teamLabel)
        view.addSubview(goalLabel)
        view.addSubview(chartView)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        setDataCount(7, range: UInt32(10000))
    }
    
    var isShowCharts: Bool = true
    var weekDates: [String] = []
    var playerData: [String: AnyObject] = [:]
    
    // MARK: - UI Setup
    
    // MARK: Charts
    let chartView: BarChartView! = {
        let chartView = BarChartView()
        let leftAxis = chartView.getAxis(.left)
        let xAxis = chartView.xAxis
        xAxis.labelPosition = .bottom
        xAxis.labelFont = .systemFont(ofSize: 10)
        xAxis.granularity = 1
        xAxis.labelCount = 7
        xAxis.valueFormatter = DayAxisValueFormatter()
        return chartView
    }()
    
    let progressView: RingProgressView! = {
        let ringProgressView = RingProgressView(frame: CGRect(x: 0, y: 100, width: 100, height: 100))
        ringProgressView.startColor = .orange
        ringProgressView.endColor = .magenta
        ringProgressView.ringWidth = 25
        ringProgressView.progress = 0.0
        return ringProgressView
    }()
    
    let percentLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 45.0)
        $0.textColor = .orange
        $0.text = "0%"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let rankLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 20.0)
        $0.textColor = .orange
        $0.text = "No.1"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let teamLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 20.0)
        $0.textColor = .orange
        $0.text = ""
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let goalLabel: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 14.0)
        $0.textColor = .orange
        $0.text = "10000 steps to goal"
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    func setDataCount(_ count: Int, range: UInt32) {
        
        let start = 0
        let yVals = (start..<start + count).map { (i) -> BarChartDataEntry in
            if (i + 1 > weekDates.count) { return BarChartDataEntry(x: Double(i), y: 0.0) }
            guard let day = weekDates[i] as? String, let playerData = playerData["allRecord"]?[day] as? [String: AnyObject], let steps = playerData["Steps"] as? String else {
                return BarChartDataEntry(x: Double(i), y: 0.0)
            }
            return BarChartDataEntry(x: Double(i), y: Double(steps) ?? 0.0)
        }
        
        var set1: BarChartDataSet! = nil
        if let set = chartView.data?.dataSets.first as? BarChartDataSet {
            set1 = set
            set1.replaceEntries(yVals)
            chartView.data?.notifyDataChanged()
            chartView.notifyDataSetChanged()
        }
        else {
            set1 = BarChartDataSet(entries: yVals, label: "Steps")
            set1.colors = ChartColorTemplates.material()
            set1.drawValuesEnabled = false
            
            let data = BarChartData(dataSet: set1)
            data.setValueFont(UIFont(name: "HelveticaNeue-Light", size: 10)!)
            data.barWidth = 0.9
            chartView.data = data
        }
        
//        chartView.setNeedsDisplay()
    }
}

class DayAxisValueFormatter: NSObject, IAxisValueFormatter {
    
    let days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
    
    func stringForValue(_ value: Double, axis: AxisBase?) -> String {
        let day = Int(value)
        return days[day]
    }
}
