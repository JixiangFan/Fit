//
//  HomePageAnalysisView_Layout.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit

extension HomePageAnalysisViewController {

    // MARK: - Layout
    override func viewDidLayoutSubviews() {
        
        super.viewDidLayoutSubviews()

        progressView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(40.0)
            if (isShowCharts) {
                make.width.height.equalTo(0)
            } else {
                make.width.height.equalTo(240)
            }
        }
        percentLabel.snp.makeConstraints { (make) in
            make.center.equalTo(progressView)
            make.leading.trailing.equalToSuperview()
            if (isShowCharts) {
                make.height.equalTo(0)
            } else {
                make.height.equalTo(46.0)
            }
        }
        teamLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(progressView)
            make.bottom.equalTo(percentLabel.snp.top).offset(-4.0)
            make.leading.trailing.equalToSuperview()
            if (isShowCharts) {
                make.height.equalTo(0)
            } else {
                make.height.equalTo(21.0)
            }
        }
        rankLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(progressView)
            make.bottom.equalTo(teamLabel.snp.top).offset(-2.0)
            make.leading.trailing.equalToSuperview()
            if (isShowCharts) {
                make.height.equalTo(0)
            } else {
                make.height.equalTo(21.0)
            }
        }
        goalLabel.snp.makeConstraints { (make) in
            make.centerX.equalTo(progressView)
            make.top.equalTo(percentLabel.snp.bottom).offset(4.0)
            make.leading.trailing.equalToSuperview()
            if (isShowCharts) {
                make.height.equalTo(0)
            } else {
                make.height.equalTo(16.0)
            }
        }
        
        // MARK: - Charts Layout
        chartView.snp.makeConstraints { (make) in
            make.top.equalTo(progressView.snp.bottom).offset(20.0)
            if (isShowCharts) {
                make.height.equalTo(280.0)
            } else {
                make.height.equalTo(0)
            }
            make.leading.equalToSuperview().offset(20.0)
            make.trailing.bottom.equalToSuperview().offset(-20.0)
        }
    }
}
