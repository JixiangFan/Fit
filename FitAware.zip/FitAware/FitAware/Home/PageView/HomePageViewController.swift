//
//  HomePageViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import XLPagerTabStrip

class HomePageViewController: ButtonBarPagerTabStripViewController {

    override func viewDidLoad() {
        setupPageControl()
        super.viewDidLoad()
        buttonBarView.tintColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        containerView.bounces = false
    }
    
    let teamHistoryVC = TeamHistoryViewController()
    let todayStepsVC = TodayStepsViewController()
    let currentStepsVC = CurrentStepsViewController()
    
    override public func viewControllers(for pagerTabStripController: PagerTabStripViewController) -> [UIViewController] {
        
        return [teamHistoryVC, todayStepsVC, currentStepsVC]
    }
    
    // MARK: - UI Setup
    func setupPageControl() {
        settings.style.buttonBarBackgroundColor = .white
        settings.style.selectedBarBackgroundColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        settings.style.buttonBarItemTitleColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        settings.style.buttonBarItemBackgroundColor = .white
        settings.style.buttonBarHeight = 60.0
    }
    
    func refresh() {
        teamHistoryVC.refresh()
        todayStepsVC.refresh()
    }
}
