//
//  TeamHistoryVC_Layout.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import FirebaseUI

extension TeamHistoryViewController {
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(220.0)
        }
    }
}

extension TeamHistoryViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playerData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        #warning("TO FIX")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomePageCollectionCell", for: indexPath) as! HomePageCollectionCell
        cell.progressRing.progress = 1.0
        let referenceURL = "user_icon/\(playerData[indexPath.row]["teamMember"] as? String ?? "")/icon.jpg"
        let reference = Storage.storage().reference().child(referenceURL)
        cell.playerIcon.sd_setImage(with: reference, placeholderImage: #imageLiteral(resourceName: "teamwork.png"))
        cell.playerNameLabel.text = playerData[indexPath.row]["teamMember"] as? String ?? ""
        cell.rankLabel.text = "No.\(indexPath.row + 1)"
        cell.totalStepsLabel.text = "Steps: \(playerData[indexPath.row]["Steps"] as? String ?? "0")"
        return cell
    }
}
