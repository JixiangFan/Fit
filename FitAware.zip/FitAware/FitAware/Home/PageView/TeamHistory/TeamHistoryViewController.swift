//
//  TeamHistoryViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import XLPagerTabStrip
import PopupDialog
import SwiftDate
import Firebase

class TeamHistoryViewController: UIViewController, IndicatorInfoProvider, UICollectionViewDelegate {
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(image: #imageLiteral(resourceName: "Home_History.png"))
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        
        PopupDialogOverlayView.appearance().color = .clear
        PopupDialogContainerView.appearance()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refresh()
    }
    
    // MARK: - CollectionView
    let collectionView: UICollectionView! = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0.0
        flowLayout.itemSize = CGSize(width: 140, height: 220)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.register(UINib(nibName: "HomePageCollectionCell", bundle: nil), forCellWithReuseIdentifier: "HomePageCollectionCell")
        collectionView.backgroundColor = .white
        return collectionView
    }()

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let analysisViewController = HomePageAnalysisViewController()
        analysisViewController.weekDates = weekDates
        analysisViewController.playerData = playerData[indexPath.row]
        analysisViewController.isShowCharts = true
        analysisViewController.progressView.isHidden = true
        let popView = PopupDialog(viewController: analysisViewController)
        self.present(popView, animated: true, completion: nil)
    }
    
    var weekDates: [String] = []
    var teamMembers: [String] = []
    var playerData: [[String: AnyObject]] = []
        
    func refresh() {
        
        // Calculate Week Date
        let endDate = DateInRegion(region: .current)
        let startDate = endDate.dateAt(.startOfWeek)
        let increment = DateComponents.create {
            $0.hour = 24
        }
        let dates = DateInRegion.enumerateDates(from: startDate, to: endDate, increment: increment)
        var weekdays = [String]()
        for date in dates {
            let dateStr = date.toFormat("yyyy-MM-dd")
            weekdays.append(dateStr)
        }
        weekDates = weekdays
        
        // Request Team Data
        UserDataCenter.shared.requestTeamData(completion: { (teamData) in
            guard let teamMembers = teamData["teamMembers"] as? [String: Any] else { return }
            var teamMembersArr = [String]()
            for teamPlayer in teamMembers.keys {
                teamMembersArr.append(teamPlayer)
            }
            self.teamMembers = teamMembersArr
            self.calculateTeamRank()
        }) {

        }
    }
    func calculateTeamRank() {
        
        self.playerData = []
        let ref: DatabaseReference! = Database.database().reference()
        for teamMember in teamMembers {
            ref.child("DailyRecord").child(teamMember).observeSingleEvent(of: .value, with: { [weak self] (snapshot) in
                guard let value = snapshot.value as? NSDictionary else { return }
                    
                var stepsCountSum = 0
                for dailyRecord in self?.weekDates ?? [] {
                    if let dailyData = value[dailyRecord] as? [String: String] {
                        let stepsValue = dailyData["Steps"]
                        let stepsCount = Int(stepsValue ?? "0") ?? 0
                        stepsCountSum += stepsCount
                    }
                }
                let playerDict = ["Steps": String(stepsCountSum), "teamMember": teamMember, "allRecord": value] as [String : AnyObject]
                self?.playerData.append(playerDict as [String : AnyObject])
                self?.playerData.sort(by: {
                    Int($0["Steps"] as? String ?? "0")! > Int($1["Steps"] as? String ?? "0")!
                })
                self?.collectionView.reloadData()
                return
              }) { (error) in
                print(error.localizedDescription)
            }
        }
    }
}
