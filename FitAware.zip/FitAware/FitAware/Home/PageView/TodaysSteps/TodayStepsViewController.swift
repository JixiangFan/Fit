//
//  TodayStepsViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import XLPagerTabStrip
import PopupDialog
import Firebase
import SwiftDate

class TodayStepsViewController: UIViewController, IndicatorInfoProvider {
    
    func indicatorInfo(for pagerTabStripController: PagerTabStripViewController) -> IndicatorInfo {
        return IndicatorInfo(image: #imageLiteral(resourceName: "Home_Today"))
    }
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate = self
        view.addSubview(collectionView)
        
        PopupDialogOverlayView.appearance().color = .clear
        PopupDialogContainerView.appearance()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refresh()
    }
    
    // MARK: - CollectionView
    let collectionView: UICollectionView! = {
        let flowLayout = UICollectionViewFlowLayout()
        flowLayout.scrollDirection = .horizontal
        flowLayout.minimumLineSpacing = 0.0
        flowLayout.itemSize = CGSize(width: 140, height: 220)
        let collectionView = UICollectionView(frame: .zero, collectionViewLayout: flowLayout)
        collectionView.register(UINib(nibName: "HomePageCollectionCell", bundle: nil), forCellWithReuseIdentifier: "HomePageCollectionCell")
        collectionView.backgroundColor = .white
        return collectionView
    }()

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let analysisViewController = HomePageAnalysisViewController()
        analysisViewController.isShowCharts = false
        analysisViewController.goalLabel.text = (playerData[indexPath.row]["Goal"] ?? "0") + " steps to goal"
        let progress = Double(playerData[indexPath.row]["progress"] ?? "0") ?? 0.0
        let progressPrecent = "\(Int(progress * 100))%"
        analysisViewController.progressView.progress = progress
        analysisViewController.percentLabel.text = progressPrecent
        analysisViewController.teamLabel.text = playerData[indexPath.row]["teamMember"]
        analysisViewController.rankLabel.text = "NO.\(indexPath.row + 1)"
        let popView = PopupDialog(viewController: analysisViewController)
        self.present(popView, animated: true, completion: nil)
    }
    
    var teamMembers: [String] = []
    var playerData: [[String: String]] = []
    
    func refresh() {
        // Request Team Data
        UserDataCenter.shared.requestTeamData(completion: { (teamData) in
            guard let teamMembers = teamData["teamMembers"] as? [String: Any] else { return }
            var teamMembersArr = [String]()
            for teamPlayer in teamMembers.keys {
                teamMembersArr.append(teamPlayer)
            }
            self.teamMembers = teamMembersArr
            self.calculateTeamRank()
        }) {

        }
    }
    
    func calculateTeamRank() {
        self.playerData = []
        let currentDate = DateInRegion(Date(), region: .current).toFormat("yyyy-MM-dd")
        let ref: DatabaseReference! = Database.database().reference()
        for teamMember in teamMembers {
            ref.child("DailyRecord").child(teamMember).observeSingleEvent(of: .value, with: { [weak self] (snapshot) in
                guard let value = snapshot.value as? NSDictionary else { return }
                    
                var stepsCount = 0
                var goal = 0
                if let dailyData = value[currentDate] as? [String: String] {
                    let stepsValue = dailyData["Steps"]
                    let goalValue = dailyData["Goal"]
                    goal = Int(goalValue ?? "0") ?? 0
                    stepsCount = Int(stepsValue ?? "0") ?? 0
                }
                var progress: Float = 1.0
                if (goal != 0) { progress = Float(stepsCount) / Float(goal)}
                let playerDict = ["Steps": String(stepsCount), "teamMember": teamMember, "Goal": String(goal), "progress": String(progress)]
                self?.playerData.append(playerDict)
                self?.playerData.sort(by: {
                    Int($0["Steps"] ?? "0")! > Int($1["Steps"] ?? "0")!
                })
                self?.collectionView.reloadData()
                return
              }) { (error) in
                print(error.localizedDescription)
            }
        }
    }
}
