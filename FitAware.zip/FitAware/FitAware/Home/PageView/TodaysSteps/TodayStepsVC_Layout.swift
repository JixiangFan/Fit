//
//  TodayStepsVC_Layout.swift
//  FitAware
//
//  Created by Zfan on 2019/9/30.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import Firebase

extension TodayStepsViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(220.0)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return playerData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        #warning("TO FIX")
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "HomePageCollectionCell", for: indexPath) as! HomePageCollectionCell
        cell.progressRing.progress = Double(playerData[indexPath.row]["progress"] ?? "1.0") ?? Double.zero
        let referenceURL = "user_icon/\(playerData[indexPath.row]["teamMember"] ?? "")/icon.jpg"
        let reference = Storage.storage().reference().child(referenceURL)
        cell.playerIcon.sd_setImage(with: reference, placeholderImage: #imageLiteral(resourceName: "teamwork.png"))
        cell.playerNameLabel.text = playerData[indexPath.row]["teamMember"]
        cell.rankLabel.text = "No.\(indexPath.row + 1)"
        cell.totalStepsLabel.text = "\(playerData[indexPath.row]["Steps"] ?? "0")/\(playerData[indexPath.row]["Goal"] ?? "0")"
        return cell
    }
}
