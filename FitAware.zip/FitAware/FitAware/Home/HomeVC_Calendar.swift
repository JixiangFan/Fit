//
//  HomeVC_Calendar.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import VACalendar
import SwiftDate
import PopupDialog

// MARK: - Calendar Selection
extension HomeViewController: VACalendarViewDelegate {
    
    func selectedDate(_ date: Date) {
        let date = DateInRegion(date, region: .current).toFormat("yyyy-MM-dd")
        guard let records = HistoryDataCenter.shared.dailyRecords else { return }
        guard let dayRecord = records[date],
            let daySteps = dayRecord["Steps"] as? String,
            let dayGoal = dayRecord["Goal"] as? String
        else { return }
        let popView = PopupDialog(title: date, message: "Steps: \(daySteps) / \(dayGoal)")
        present(popView, animated: true, completion: nil)
        print(date)
    }
}

extension HomeViewController: VAMonthHeaderViewDelegate {
    
    func didTapNextMonth() {
        homeCalendar.calendarView.nextMonth()
    }
    
    func didTapPreviousMonth() {
        homeCalendar.calendarView.previousMonth()
    }
}

