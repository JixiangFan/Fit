//
//  HomeCalendar_Layout.swift
//  FitAware
//
//  Created by Zfan on 2019/9/23.
//  Copyright © 2019 Zfan. All rights reserved.
//

import SnapKit

extension HomeCalendar {
    
    // MARK: - Layout
    override func layoutSubviews() {

        super.layoutSubviews()
        
        calendarTitle.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(50.0)
        }
        
        calendarWeekDayBar.snp.makeConstraints { (make) in
            make.top.equalTo(calendarTitle.snp.bottom)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(30.0)
        }
        
        calendarView.snp.makeConstraints { (make) in
            make.top.equalTo(calendarWeekDayBar.snp.bottom)
            make.leading.trailing.bottom.equalToSuperview()
        }
        calendarView.setup()
    }
}
