//
//  HomeCalendar_DayViewAppearance.swift
//  FitAware
//
//  Created by Zfan on 2019/9/22.
//  Copyright © 2019 Zfan. All rights reserved.
//

import VACalendar

extension HomeCalendar: VADayViewAppearanceDelegate {
    
    func font(for state: VADayState) -> UIFont {
        
        return UIFont.systemFont(ofSize: 15.0, weight: .heavy)
    }
    
    func textColor(for state: VADayState) -> UIColor {
        
        switch state {
        case .out:
            return .lightGray
        case .selected:
            return .white
        case .unavailable:
            return #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        default:
            return #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        }
    }
    
    func textBackgroundColor(for state: VADayState) -> UIColor {
        
        switch state {
        case .selected:
            return .red
        default:
            return .clear
        }
    }
    
    func shape() -> VADayShape {
        
        return .circle
    }
    
    func dotBottomVerticalOffset(for state: VADayState) -> CGFloat {
        
        switch state {
        case .selected:
            return 2
        default:
            return -7
        }
    }
}

