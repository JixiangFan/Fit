//
//  HomeCalendar.swift
//  FitAware
//
//  Created by Zfan on 2019/9/22.
//  Copyright © 2019 Zfan. All rights reserved.
//

import VACalendar
import SnapKit
import Firebase
import SwiftDate

class HomeCalendar: UIView {
    
    // MARK: - Initialization
    
    init() {
        super.init(frame: .zero)
        backgroundColor = .white
        self.addSubview(calendarTitle)
        self.addSubview(calendarWeekDayBar)
        self.addSubview(calendarView)
        calendarView.monthDelegate = calendarTitle
        calendarView.dayViewAppearanceDelegate = self
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    static let defaultCalendar: Calendar = {
        
        var calendar = Calendar.current
        calendar.firstWeekday = 1
        calendar.timeZone = .current
        return calendar
    }()
    
    // MARK: - Data
    
    override func didMoveToSuperview() {
        super.didMoveToSuperview()
        requestData()
    }
    
    func requestData() {
        
        let dataCenter = HistoryDataCenter.shared
        dataCenter.requestUserDailyRecord(completion: { [weak self] (historyData) in
            guard let userTeam = UserDefaults.standard.value(forKey: "UserTeam") as? String else { return }
            var dates: [Date] = []
            for dateStr in historyData.keys {
                if let date = dateStr.toDate()?.date {
                    dates.append(date)
                }
            }
            self?.calendarView.selectDates(dates)
        }) { [weak self] in
            #warning("TO FIX")
        }
    }
    
    // MARK: - UI Setup
    
    var calendarTitle: VAMonthHeaderView! = {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "LLLL  YYYY"
        let appereance = VAMonthHeaderViewAppearance(
            monthFont: UIFont.systemFont(ofSize: 20.0, weight: .heavy),
            monthTextColor: #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1),
            monthTextWidth: 180.0,
            previousButtonImage: #imageLiteral(resourceName: "back"),
            nextButtonImage: #imageLiteral(resourceName: "forward"),
            dateFormatter: dateFormatter
        )
        $0.appearance = appereance
        $0.tintColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        return $0
    }(VAMonthHeaderView())
    
    var calendarWeekDayBar: VAWeekDaysView! = {
        $0.appearance = VAWeekDaysViewAppearance(
            symbolsType: .short,
            weekDayTextColor: #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1),
            weekDayTextFont: UIFont.systemFont(ofSize: 14.0, weight: .heavy),
            leftInset: 0.0,
            rightInset: 0.0,
            calendar: defaultCalendar
        )
        
        return $0
    }(VAWeekDaysView())
    
    var calendarView: VACalendarView! = {

        $0.showDaysOut = true
        $0.selectionStyle = .none
        $0.scrollDirection = .horizontal
        return $0
    }(VACalendarView(frame: .zero, calendar: VACalendar(calendar: defaultCalendar)))
}
