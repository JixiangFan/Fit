//
//  HomeDateSwitchBar.swift
//  FitAware
//
//  Created by Zfan on 2019/9/22.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import SnapKit
import SwiftDate

class HomeDateSwitchBar: UIView {
    
    // MARK: - Initialization
    
    init() {
        super.init(frame: .zero)
        self.backgroundColor = .groupTableViewBackground
        self.addSubview(dateTitle)
        self.addSubview(switchButton)
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    // MARK: - UI Setup
    
    let dateTitle: UILabel! = {
        $0.font = UIFont(name: "DINAlternate-Bold", size: 30.0)
        $0.textColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        $0.text = DateInRegion(Date(), region: .current).toFormat("MMMM dd")
        $0.textAlignment = .center
        return $0
    }(UILabel())
    
    let switchButton: UIButton! = {
        $0.setImage(#imageLiteral(resourceName: "down.png"), for: .normal)
        $0.tintColor = #colorLiteral(red: 0, green: 0.785437076, blue: 0.7799295775, alpha: 1)
        $0.isHighlighted = false
        return $0
    }(UIButton(type: .custom))
    
    // MARK: - Layout
    
    override func layoutSubviews() {

        super.layoutSubviews()
        dateTitle.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.top.bottom.equalToSuperview()
            make.width.equalToSuperview().multipliedBy(0.5)
        }
        switchButton.snp.makeConstraints { (make) in
            make.right.equalToSuperview().inset(20.0)
            make.width.equalTo(50.0)
            make.top.bottom.centerY.equalToSuperview()
        }
    }
    
    // MARK: - Switch
    func switchStatus(isHidden: Bool) {
        if isHidden {
            switchButton.setImage(#imageLiteral(resourceName: "down.png"), for: .normal)
        }
        else {
            switchButton.setImage(#imageLiteral(resourceName: "up.png"), for: .normal)
        }
    }
}
