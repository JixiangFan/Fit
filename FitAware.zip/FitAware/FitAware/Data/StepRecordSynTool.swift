//
//  StepRecordSynTool.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import Firebase
import SwiftDate
import HealthKit
import CoreMotion

class StepRecordTool: NSObject {
    
    // Singleton
    static let shared = StepRecordTool()
    private override init() {}
    
    // Firebase
    lazy var ref: DatabaseReference! = Database.database().reference()
    let stepsMonitor = CMPedometer()
    let teamStepsMonitor = CMPedometer()
    
    // Steps Count
    func getCurrentSteps(completion: @escaping (String) -> Void) {
        
        let startDate = DateInRegion(Date(), region: .current).dateAtStartOf(.day)
//        stepsMonitor.startUpdates(from: startDate.date) { (data, error) in
//            guard let data = data else { return }
//            self.stepsMonitor.stopUpdates()
//            print(data.numberOfSteps)
//            completion(String(data.numberOfSteps.intValue))
//        }
        stepsMonitor.queryPedometerData(from: startDate.date, to: Date()) { (data, error) in
            guard let data = data else { return }
            print(data.numberOfSteps)
            completion(String(data.numberOfSteps.intValue))
        }
    }
    
    func updateCurrentStep() {
        
        guard let userID = UserDataCenter.shared.userID else { return }
        getCurrentSteps { (currentSteps) in
            let postKey = DateInRegion(Date(), region: .current).toFormat("yyyy-MM-dd")
            let postValue = ["Cals": "0", "Goal": "10000", "HPs": "0", "Minis": "0", "Ms": "0", "Rank": "0", "Steps": currentSteps, "Token": ""]
            self.ref.child("DailyRecord").child(userID).updateChildValues([postKey: postValue])
        }
    }
    
    func updateTeamSteps() {
        
        UserDataCenter.shared.requestTeamData(completion: { (teamData) in
            guard let userID = UserDataCenter.shared.userID else { return }
            guard let userTeam = UserDataCenter.shared.userTeam else { return }
            let currentDate = DateInRegion(Date(), region: .current).toFormat("yyyy-MM-dd")
            let startDate = DateInRegion(Date(), region: .current).dateAtStartOf(.day)
            self.teamStepsMonitor.queryPedometerData(from: startDate.date, to: Date()) { (data, error) in
                guard let data = data else { return }
                print(data.numberOfSteps)
                let postValue = String(data.numberOfSteps.uintValue)
                if let allUpdate = teamData["teamStepsRecord"] as? [String: Any], let todayUpdate = allUpdate[currentDate] as? String, !todayUpdate.isEmpty {
                    self.ref.child("Teams").child(userTeam).child("teamStepsRecord").child(currentDate).updateChildValues([userID: postValue])
                } else {
                    self.ref.child("Teams").child(userTeam).child("teamStepsRecord").setValue([currentDate: [userID: postValue]])
                }
            }
        }) {
    
        }
    }
    
    func requestAuthorization() {
        
        let healthStore = HKHealthStore()
        let allTypes = Set([HKObjectType.quantityType(forIdentifier: .stepCount)!])
        healthStore.requestAuthorization(toShare: nil, read: allTypes, completion: {_,_ in })
    }
}
