//
//  TeamDataCenter.swift
//  FitAware
//
//  Created by Zfan on 2019/10/7.
//  Copyright © 2019 Zfan. All rights reserved.
//

import Foundation
import Firebase
import SwiftDate

class TeamDataCenter: NSObject {

    // Singleton
    static let shared = TeamDataCenter()
    private override init() {}
    
    lazy var ref: DatabaseReference! = Database.database().reference()
    
    func requestAllTeamData(completion: @escaping (Array<Dictionary<String, Any>>) -> Void, failure:  @escaping () -> Void) {
        ref.child("Teams").observeSingleEvent(of: .value, with: {(snapshot) in
            guard let value = snapshot.value as? [String: Any] else {
                failure()
                return
            }
            
            var teamsArr: [Dictionary<String, Any>] = []
            for teamName in value.keys {
                guard var teamInfo = value[teamName] as? Dictionary<String, Any> else { continue }
                teamInfo.updateValue(teamName, forKey: "TeamName")
                teamsArr.append(teamInfo)
            }
            
            var sortTeamsArr: [Dictionary<String, Any>] = []
//            var noDataTeamArr: [Dictionary<String, Any>] = []
            for var team in teamsArr {
                guard let teamStepsRecord = team["teamStepsRecord"] as? [String: AnyObject] else {
//                    noDataTeamArr.append(team)
                    continue
                }
                let currentDate = DateInRegion(Date(), region: .current).toFormat("yyyy-MM-dd")
                guard let currentSteps = teamStepsRecord[currentDate] as? [String: AnyObject] else {
//                    noDataTeamArr.append(team)
                    continue
                }
                var sumStepsCount: UInt = 0
                for player in currentSteps.keys {
                    let steps = currentSteps[player] as? String ?? "0"
                    let stepsCount = UInt(steps) ?? 0
                    sumStepsCount = sumStepsCount + stepsCount
                }
                let sumSteps = String(sumStepsCount)
                team.updateValue(sumSteps, forKey: "teamSteps")
                sortTeamsArr.append(team)
            }
//            sortTeamsArr.append(contentsOf: noDataTeamArr)
            sortTeamsArr.sort(by: {
                Int($0["teamSteps"] as? String ?? "0")! > Int($1["teamSteps"] as? String ?? "0")!
            })
            completion(sortTeamsArr)
        }) { (error) in
            failure()
            print(error.localizedDescription)
        }
    }
}
