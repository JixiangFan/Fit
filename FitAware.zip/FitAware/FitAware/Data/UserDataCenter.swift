//
//  UserDataCenter.swift
//  FitAware
//
//  Created by Zfan on 2019/9/19.
//  Copyright © 2019 Zfan. All rights reserved.
//

import Foundation
import Firebase

class UserDataCenter: NSObject {

    // Singleton
    static let shared = UserDataCenter()
    private override init() {}
    
    var userID: String? {
        get {
            guard let userID = UserDefaults.standard.value(forKey: "UserID") as? String else { return nil }
            if userID.isEmpty { return nil }
            return userID
        }
        set {
            guard newValue != nil else { return }
            UserDefaults.standard.setValue(newValue, forKey: "UserID")
        }
    }
    
    var userTeam: String? {
        get {
            guard let userID = UserDefaults.standard.value(forKey: "UserTeam") as? String else { return nil }
            if userID.isEmpty { return nil }
            return userID
        }
        set {
            guard newValue != nil else { return }
            UserDefaults.standard.setValue(newValue, forKey: "UserTeam")
        }
    }
    
    var userPassword: String? {
        get {
            guard let userID = UserDefaults.standard.value(forKey: "UserPwd") as? String else { return nil }
            if userID.isEmpty { return nil }
            return userID
        }
        set {
            guard newValue != nil else { return }
            UserDefaults.standard.setValue(newValue, forKey: "UserPwd")
        }
    }
    
    var userEmail: String? {
        get {
            guard let email = UserDefaults.standard.value(forKey: "userEmail") as? String else { return nil }
            if email.isEmpty { return nil }
            return email
        }
        set {
            guard newValue != nil else { return }
            UserDefaults.standard.setValue(newValue, forKey: "userEmail")
        }
    }
    
    var userInfo: Dictionary<String, Any>?
    var teamInfo: Dictionary<String, Any>?

    lazy var ref: DatabaseReference! = Database.database().reference()
    
    func requestUserInfo() {
        
        guard let userID = userID else { return }
        ref.child("User").child(userID).observeSingleEvent(of: .value, with: { [weak self] (snapshot) in
            guard let value = snapshot.value as? NSDictionary else { return }
            self?.userInfo = value as? [String : Any]
          }) { (error) in
            print(error.localizedDescription)
        }
    }

    func requestTeamData(completion: @escaping (Dictionary<String, Any>) -> Void, failure:  @escaping () -> Void) {
        
        guard let userTeam = userTeam else { return }
        ref.child("Teams").child(userTeam).observeSingleEvent(of: .value, with: { [weak self] (snapshot) in
            guard let value = snapshot.value as? [String: Any] else {
                failure()
                return
            }
            self?.teamInfo = value
            completion(value)
        }) { (error) in
            failure()
            print(error.localizedDescription)
        }
    }
    
    func resetUserInfo() {
        userID = ""
        userTeam = ""
        userEmail = ""
        userPassword = ""
    }
}
