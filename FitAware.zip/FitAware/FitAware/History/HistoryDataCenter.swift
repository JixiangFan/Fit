//
//  HistoryDataCenter.swift
//  FitAware
//
//  Created by Zfan on 2019/9/11.
//  Copyright © 2019 Zfan. All rights reserved.
//

import Firebase

class UserDailyModel: Codable {
    var Steps: String?
    var Goal: String?
    var Rank: String?
}

class HistoryDataCenter: NSObject {
    
    // Singleton
    static let shared = HistoryDataCenter()
    private override init() {}
    
    private var ref: DatabaseReference! = Database.database().reference()
    var dailyRecords: [String: [String: Any]]?
        
    func requestUserDailyRecord(completion: @escaping ([String: Any]) -> Void, failure:  @escaping () -> Void) {
        
        let userID = UserDataCenter.shared.userID ?? ""
        if userID.isEmpty { return }
        ref.child("DailyRecord").child(userID).observeSingleEvent(of: .value, with: { (snapshot) in
            guard let value = snapshot.value as? [String: [String: Any]] else {
                failure()
                return
            }
            self.dailyRecords = value
            completion(value)
        }) { (error) in
            print(error.localizedDescription)
            failure()
        }
    }
}
