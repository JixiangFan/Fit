//
//  HistoryViewCell.swift
//  FitAware
//
//  Created by Zfan on 2019/9/10.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import SnapKit
import RPCircularProgress

class HistoryViewCell: UITableViewCell {
    
    @IBOutlet weak var ringProgressView: RPCircularProgress!
    @IBOutlet weak var dateTitle: UILabel!
    @IBOutlet weak var rankView: UILabel!
    @IBOutlet weak var stepsCount: UILabel!
    
    // MARK: - Initiation
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    // MARK: - UI Setup
    
    func setupUI() {
        self.selectionStyle = .none
    }
}
