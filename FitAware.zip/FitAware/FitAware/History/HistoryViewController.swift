//
//  HistoryViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import ESPullToRefresh

class HistoryViewController: UITableViewController {
    
    let CellReuseIdentifier = "HistoryViewCell"

    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: "HistoryViewCell", bundle: nil), forCellReuseIdentifier: CellReuseIdentifier)
        setRefreshModule()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        doRefreshOnce()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopRefresh()
    }
    
    //MARK: - UI Setup
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CellReuseIdentifier, for: indexPath)
        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return historyData?.keys.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 160.0
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let historyCell = cell as? HistoryViewCell {
            let index = indexPath.row
            guard let dateKey = dateArray?[index] else { return }
            guard let cellData = historyData?[dateKey] else { return }
            
            historyCell.dateTitle.text = dateKey
            historyCell.rankView.text = cellData["Rank"] as? String ?? "1"
            
            let steps = cellData["Steps"] as? String ?? "0"
            historyCell.stepsCount.text = steps
            
            let goal = cellData["Goal"] as? String ?? "0"
            let progress = calculateProgress(steps: steps, goal: goal)
            historyCell.ringProgressView.updateProgress(progress, animated: false, initialDelay: 0.0, duration: 0.0, completion: nil)
        }
    }
    
    override func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if let historyCell = cell as? HistoryViewCell {
            historyCell.ringProgressView.updateProgress(0.0, animated: false, initialDelay: 0.0, duration: 0.0, completion: nil)
        }
    }
    
    //MARK: - Data Setup
    
    var historyData: [String: [String: Any]]?
    
    var dateArray: [String]? {
        didSet {
            tableView.reloadData()
        }
    }
    
    func requestHistoryData() {
        let dataCenter = HistoryDataCenter.shared
        dataCenter.requestUserDailyRecord(completion: { [weak self] (historyData) in
            self?.historyData = historyData as? [String : Dictionary<String, Any>]
            self?.dateArray = historyData.keys.sorted().reversed()
            self?.stopRefresh()
        }) { [weak self] in
            let alert = UIAlertController(title: "Sorry, No Steps Record!", message: nil, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self?.present(alert, animated: true)
            self?.historyData = nil
            self?.dateArray = nil
            self?.stopRefresh()
        }
    }
    
    func calculateProgress(steps: String, goal: String) -> CGFloat {
        let stepsCount = CGFloat(steps.count), goalCount = CGFloat(goal.count)
        if (stepsCount >= goalCount) { return 1.0 }
        return stepsCount / goalCount
    }
    
    // MARK: - Refresh
    
    func setRefreshModule() {
        tableView.es.addPullToRefresh {
            [unowned self] in
            self.requestHistoryData()
        }
    }
    
    func doRefreshOnce() {
        tableView.es.startPullToRefresh()
    }
    
    func stopRefresh() {
        tableView.es.stopPullToRefresh()
    }
}
