//
//  TabViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import HealthKit
import SwiftDate

class TabViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        checkUserLoginStatus()
    }
    
    // MARK: - Data Initiazion
    func checkUserLoginStatus() {
        guard UserDataCenter.shared.userID != nil else {
            let popVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
            UIApplication.shared.keyWindow?.rootViewController = popVC
            return
        }
    }
}
