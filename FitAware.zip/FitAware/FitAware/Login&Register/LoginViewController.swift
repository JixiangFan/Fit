//
//  LoginViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/12.
//  Copyright © 2019 Zfan. All rights reserved.
//

import TextFieldEffects
import Firebase
import PopupDialog

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        
        super.viewDidLoad()
        if let userID = UserDefaults.standard.value(forKey: "UserID") as? String,
            let password = UserDefaults.standard.value(forKey: "Password") as? String {
            userName.text = userID
            userPassword.text = password
        }
    }
    @IBOutlet weak var userName: HoshiTextField!
    @IBOutlet weak var userPassword: HoshiTextField!
    @IBOutlet weak var isRememberPwd: UISwitch!
    
    // MARK: - login
    @IBAction func requestLogin(_ sender: Any) {
        view.endEditing(true)
        requestToCheckUserInfo()
    }
    
    // MARK: - Register
    @IBAction func requestRegister(_ sender: Any) {
        toRegisterPage()
    }
    
    // MARK: - Forgot Pwd
    @IBAction func forgotPwd(_ sender: Any) {
        
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        view.endEditing(true)
    }
    
    // MARK: - Business Logic
    
    // Firebase
    var ref: DatabaseReference! = Database.database().reference()
    
    func requestToCheckUserInfo() {
        
        guard let userID = userName.text, !userID.isEmpty else { return }
        ref.child("User").child(userID).observeSingleEvent(of: .value, with: { [weak self] (snapshot) in
            guard let value = snapshot.value as? NSDictionary else {
                self?.popAlert(Message: "UserName or Password incorrect!")
                return
            }
            // User is exsist
            guard let pwd = value["password"] as? String else {
                self?.popAlert(Message: "Login Failed! Please try again later!")
                return
            }
            guard pwd == self?.userPassword.text else {
                self?.popAlert(Message: "UserName or Password incorrect!")
                return
            }
            
            UserDataCenter.shared.userID = userID
            if self?.isRememberPwd.isOn ?? false {
                UserDataCenter.shared.userPassword = pwd
            }
            else {
                UserDataCenter.shared.userPassword = ""
            }
            if let userTeam = value["team"] as? String {
                UserDataCenter.shared.userTeam = userTeam
            }
            if let userEmail = value["email"] as? String {
                UserDataCenter.shared.userEmail = userEmail
            }
            
            self?.accessToHomePage()
            UserDefaults.resetStandardUserDefaults()
            print("========Login=========")
            return
          }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    func popAlert(Message: String) {
        let popup = PopupDialog(title: Message, message: nil, image: nil, tapGestureDismissal: false, panGestureDismissal: false)
        popup.addButton(PopupDialogButton(title: "OK", action: nil))
        present(popup, animated: true)
    }
    
    @IBAction func rememberChanged(_ sender: Any) {
        userName.text = nil
        userPassword.text = nil
        UserDataCenter.shared.resetUserInfo()
    }
    
    func accessToHomePage() {

        let mainPage = UIStoryboard(name: "main", bundle: nil)
        let mainVC = mainPage.instantiateInitialViewController()
        let transtition = CATransition()
        transtition.duration = 0.4
        transtition.type = .reveal
        transtition.subtype = .fromBottom 
        transtition.timingFunction = CAMediaTimingFunction(name: .easeOut)
        UIApplication.shared.keyWindow?.layer.add(transtition, forKey: "AccessToHomePageAnimation")
        UIApplication.shared.keyWindow?.rootViewController = mainVC
    }
    
    func toRegisterPage() {
        
        let popVC = RegisterViewController(nibName: "RegisterViewController", bundle: nil)
        popVC.modalPresentationStyle = .fullScreen
        present(popVC, animated: true, completion: nil)
    }
}
