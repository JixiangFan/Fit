//
//  RegisterViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/27.
//  Copyright © 2019 Zfan. All rights reserved.
//

import TextFieldEffects
import Firebase
import PopupDialog

class RegisterViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func didTap(_ sender: Any) {
        view.endEditing(true)
    }
    
    @IBOutlet weak var nameInput: HoshiTextField!
    @IBOutlet weak var emailInput: HoshiTextField!
    @IBOutlet weak var passwordInput: HoshiTextField!
    @IBOutlet weak var dateType: UISegmentedControl!
    @IBOutlet weak var stepsGoal: HoshiTextField!
    
    // MARK: - User Icon
    
    @IBOutlet weak var userIconView: UIImageView!
    private var _userSeletedIcon: UIImage? {
        didSet {
            userIconView.image = _userSeletedIcon
        }
    }
    
    var userSeletedIcon: UIImage? {
        get {
            return _userSeletedIcon
        }
        set {
            guard let newImage = newValue else { return }
            let siderLength = newImage.size.width > newImage.size.height ? newImage.size.height : newImage.size.width
            let imageSize = CGSize(width: siderLength, height: siderLength)
            let rect = CGRect(origin: CGPoint.zero, size: imageSize)
            UIGraphicsBeginImageContext(imageSize)
            UIColor.clear.setFill()
            UIRectFill(rect)
            let path = UIBezierPath(ovalIn: rect)
            path.addClip()
            newImage.draw(in: rect)
            var image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            
            guard image != nil else { return }
            let zipSize = CGSize(width: 200.0, height: 200.0)
            UIGraphicsBeginImageContext(zipSize)
            let zipRect = CGRect(origin: CGPoint.zero, size: zipSize)
            image?.draw(in: zipRect)
            image = UIGraphicsGetImageFromCurrentImageContext()
            UIGraphicsEndImageContext()
            _userSeletedIcon = image
        }
    }
    
    // MARK:  Icon Selection
    @IBAction func selectUserIcon(_ sender: Any) {
        let photoPickerViewController:UIImagePickerController = UIImagePickerController()
        photoPickerViewController.sourceType = .photoLibrary
        photoPickerViewController.delegate = self
        self.present(photoPickerViewController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            userSeletedIcon = selectedImage
        }
        picker.dismiss(animated: true, completion: nil)
    }
    
    // MARK: - Register
    @IBAction func toRegister(_ sender: Any) {
        checkIfUserExsist()
    }
    
    // MARK: - Data
    
    // Firebase
    var ref: DatabaseReference! = Database.database().reference()
    
    // Check If User is exsist
    func checkIfUserExsist() {
        
        guard let userID = nameInput.text else { return }
        ref.child("User").child(userID).observeSingleEvent(of: .value, with: { (snapshot) in
            if let _ = snapshot.value as? NSDictionary {
                // User is exsist
                return
            }
            self.requestRegister()
          }) { (error) in
            print(error.localizedDescription)
        }
    }
    
    let dateTypes = ["Daily", "3 Days", "5 Days", "Weekly"]
    
    func requestRegister() {

        guard let userID = nameInput.text,
              let userEmail = emailInput.text,
              let password = passwordInput.text,
              let stepsGoal = stepsGoal.text
        else { return }
        let index = dateType.selectedSegmentIndex
        let dateType = dateTypes[index]
        let postKey = userID
        let postValue = ["calories": "0",
                         "captain": "",
                         "currentSteps": "0",
                         "distance": "0",
                         "duration": "0",
                         "email": userEmail,
                         "Steps": "0",
                         "heartPoints": "0",
                         "id": userID,
                         "password": password,
                         "periodical": dateType,
                         "team": "",
                         "teamGoal": stepsGoal,
                         "teamSteps": ""]
        self.ref.child("User").setValue([postKey: postValue])
        
        let popup = PopupDialog(title: "Registration Success!", message: nil, image: nil, tapGestureDismissal: false, panGestureDismissal: false)
        popup.addButton(PopupDialogButton(title: "Return to Login", action: { [weak self] in
            self?.backToLogin([])
        }))
        present(popup, animated: true)
        
        // Upload User Icon
        let storageRef = Storage.storage().reference().child("user_icon").child(userID).child("\(userID).png")
        guard let userSeletedIcon = userSeletedIcon else { return }
        if let uploadData = userSeletedIcon.pngData() {
            storageRef.putData(uploadData, metadata: nil, completion: { (data, error) in
                if error != nil {
                    print("Error: \(error!.localizedDescription)")
                    return
                }
            })
        }
    }
    
    // MARK: - Back to Login
    @IBAction func backToLogin(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
