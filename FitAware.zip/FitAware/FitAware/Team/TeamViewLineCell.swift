//
//  TeamViewLineCell.swift
//  FitAware
//
//  Created by Zfan on 2019/9/30.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit

class TeamViewLineCell: UICollectionViewCell {
    
    @IBOutlet weak var steps: UILabel!
    @IBOutlet weak var captainName: UILabel!
    @IBOutlet weak var teamName: UILabel!
    @IBOutlet weak var indexView: UILabel!
    @IBOutlet weak var teamIcon: UIImageView!
}
