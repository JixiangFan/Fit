//
//  TeamViewCell.swift
//  FitAware
//
//  Created by Zfan on 2019/9/30.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import MKRingProgressView

class TeamViewCell: UICollectionViewCell {
    
    @IBOutlet weak var steps: UILabel!
    @IBOutlet weak var captainName: UILabel!
    @IBOutlet weak var teamName: UILabel!
    @IBOutlet weak var teamIcon: UIImageView!
    @IBOutlet weak var progressRing: RingProgressView!
}
