//
//  TeamViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import XLPagerTabStrip
import Firebase

class TeamViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.register(UINib(nibName: "TeamViewCell", bundle: nil), forCellWithReuseIdentifier: "TeamViewCell")
        collectionView.register(UINib(nibName: "TeamViewLineCell", bundle: nil), forCellWithReuseIdentifier: "TeamViewLineCell")
        refresh()
    }
    
    @IBAction func titleBarChanged(_ sender: Any) {
        
    }
    
    @IBAction func viewBarChanged(_ sender: Any) {
        if collectionView.collectionViewLayout.isMember(of: TeamViewCollectionViewGridLayout.self) {
            collectionView.collectionViewLayout = TeamViewCollectionViewLineLayout()
            self.collectionView.reloadData()
        } else {
            collectionView.collectionViewLayout = TeamViewCollectionViewGridLayout()
            self.collectionView.reloadData()
        }
    }
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    var allTeamsInfo: [Dictionary<String, Any>] = []
}

extension TeamViewController: UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return allTeamsInfo.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView.collectionViewLayout.isMember(of: TeamViewCollectionViewGridLayout.self) {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TeamViewCell", for: indexPath) as! TeamViewCell
            cell.progressRing.progress = Double(allTeamsInfo[indexPath.row]["progress"] as? String ?? "0.0") ?? Double.zero
            let referenceURL = "team_icon/\(allTeamsInfo[indexPath.row]["TeamName"] ?? "")/icon.jpg"
            let reference = Storage.storage().reference().child(referenceURL)
            cell.teamIcon.sd_setImage(with: reference, placeholderImage: #imageLiteral(resourceName: "teamwork.png"))
            cell.captainName.text = allTeamsInfo[indexPath.row]["captain"] as? String ?? ""
            cell.teamName.text = allTeamsInfo[indexPath.row]["TeamName"] as? String
            cell.steps.text = "\(allTeamsInfo[indexPath.row]["teamSteps"] ?? "0")/\(allTeamsInfo[indexPath.row]["teamGoal"] ?? "0")"
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "TeamViewLineCell", for: indexPath) as! TeamViewLineCell
//            cell.progressRing.progress = Double(allTeamsInfo[indexPath.row]["progress"] as? String ?? "0.0") ?? Double.zero
            let referenceURL = "team_icon/\(allTeamsInfo[indexPath.row]["TeamName"] ?? "")/icon.jpg"
            let reference = Storage.storage().reference().child(referenceURL)
            cell.teamIcon.sd_setImage(with: reference, placeholderImage: #imageLiteral(resourceName: "teamwork.png"))
            cell.captainName.text = allTeamsInfo[indexPath.row]["captain"] as? String ?? ""
            cell.indexView.text = "\(indexPath.row + 1)"
            cell.teamName.text = allTeamsInfo[indexPath.row]["TeamName"] as? String
            cell.steps.text = "\(allTeamsInfo[indexPath.row]["teamSteps"] ?? "0")/\(allTeamsInfo[indexPath.row]["teamGoal"] ?? "0")"
            return cell
        }
    }
    
    func refresh() {
        requestData()
    }
}

extension TeamViewController {
    
    func requestData() {
        TeamDataCenter.shared.requestAllTeamData(completion: { (allTeamsInfo) in
            self.allTeamsInfo = allTeamsInfo
            self.collectionView.reloadData()
        }) {
            print("==== UserInfoView: TeamDataCenter Request Data Error")
        }
    }
}

class TeamViewCollectionViewGridLayout: UICollectionViewFlowLayout {
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setup()
    }
    
    override init() {
        super.init()
        setup()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func setup() {
        scrollDirection = .vertical
        minimumLineSpacing = 1.0
        minimumInteritemSpacing = 1.0
        itemSize = CGSize(width: (UIApplication.shared.keyWindow!.bounds.size.width - 42.0) / 2 , height: 280.0)
    }
}

class TeamViewCollectionViewLineLayout: UICollectionViewFlowLayout {
    
    override init() {
        super.init()
        scrollDirection = .vertical
        minimumLineSpacing = 1.0
        itemSize = CGSize(width: UIApplication.shared.keyWindow!.bounds.size.width - 40.0, height: 160.0)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
