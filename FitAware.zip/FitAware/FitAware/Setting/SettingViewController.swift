//
//  SettingViewController.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import PopupDialog
import FirebaseUI

class SettingViewController: UITableViewController {

    let CellReuseIdentifier = "SettingViewCell"
    
    @IBOutlet weak var userIcon: UIImageView!
    @IBOutlet weak var userName: UILabel!
    @IBOutlet weak var userEmail: UILabel!
    @IBOutlet weak var userTeam: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setRefreshModule()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        requestUsersData()
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if (indexPath.row == 3) {
            // MARK: - Log out
            let popup = PopupDialog(title: "Do you want to logout ?", message: nil, image: nil, tapGestureDismissal: false, panGestureDismissal: false)
            popup.addButton(PopupDialogButton(title: "YES", action: {
                let popVC = LoginViewController(nibName: "LoginViewController", bundle: nil)
                UIApplication.shared.keyWindow?.rootViewController = popVC
            }))
            popup.addButton(PopupDialogButton(title: "Cancel", action: nil))
            present(popup, animated: true, completion: nil)
        }
    }
    
    func requestUsersData() {
        let dataCenter = UserDataCenter.shared
        dataCenter.requestUserInfo()
        let referenceURL = "user_icon/\(UserDataCenter.shared.userID ?? "")/icon.jpg"
        let reference = Storage.storage().reference().child(referenceURL)
        userIcon.sd_setImage(with: reference)
        userName.text = UserDataCenter.shared.userID
        userEmail.text = UserDataCenter.shared.userEmail
        userTeam.text = "In Team: " + (UserDataCenter.shared.userTeam ?? "")
    }
    
    // MARK: - Refresh
    func setRefreshModule() {
        tableView.es.addPullToRefresh {
            [unowned self] in
            self.requestUsersData()
            self.tableView.es.stopPullToRefresh()
        }
    }
    
    func doRefreshOnce() {
        tableView.es.startPullToRefresh()
    }
}
