//
//  AppDelegate.swift
//  FitAware
//
//  Created by Zfan on 2019/9/9.
//  Copyright © 2019 Zfan. All rights reserved.
//

import UIKit
import Firebase
import DeallocationChecker

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        // Firebase Init
        FirebaseApp.configure()
        
        // UserData Init
        UserDataCenter.shared.requestUserInfo()
        StepRecordTool.shared.requestAuthorization()
        
        // Background Fetch Init
        UIApplication.shared.setMinimumBackgroundFetchInterval(UIApplication.backgroundFetchIntervalMinimum)
        
        #if DEBUG
            DeallocationChecker.shared.setup(with: .alert)
        #endif
        
        return true
    }
    
    func application(_ application: UIApplication, performFetchWithCompletionHandler completionHandler: @escaping (UIBackgroundFetchResult) -> Void) {
        StepRecordTool.shared.updateCurrentStep()
        StepRecordTool.shared.updateTeamSteps()
    }

    func applicationDidEnterBackground(_ application: UIApplication) {
        StepRecordTool.shared.updateCurrentStep()
        StepRecordTool.shared.updateTeamSteps()
    }

    func applicationWillTerminate(_ application: UIApplication) {
        StepRecordTool.shared.updateCurrentStep()
        StepRecordTool.shared.updateTeamSteps()
    }
}

